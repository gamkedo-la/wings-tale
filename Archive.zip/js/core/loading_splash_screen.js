function LoadingSplashScreen()
{
        
}

var loadingSplashScreen;
